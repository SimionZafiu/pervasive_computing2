﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Surface;
using Microsoft.Surface.Presentation;
using Microsoft.Surface.Presentation.Controls;
using Microsoft.Surface.Presentation.Input;
using System.Diagnostics;
using System.Threading;

namespace SurfaceApplication1
{

    /// <summary>
    /// Interaction logic for PhoneVisualization.xaml
    /// </summary>
    public partial class PhoneVisualization : TagVisualization
    {
      
        public PhoneVisualization()
        {
            InitializeComponent();
        }

    

        private void PhoneVisualization_Loaded(object sender, RoutedEventArgs e)
        {
            //TODO: customize PhoneVisualization's UI based on this.VisualizedTag here


        }

  
        private void PinPhone_TouchDown(object sender, TouchEventArgs e)
        {
            Image img = (Image)e.Source;
            if(img.Name.Equals("Pin")) 
            { 
                
                img.Name = "Unpin";
                img.Source = new BitmapImage(new Uri(@"Resources/unpin.png", UriKind.Relative));
                this.TagRemovedBehavior = TagRemovedBehavior.Persist;


            }else{

                img.Name = "Pin";
                img.Source = new BitmapImage(new Uri(@"Resources/pin.png", UriKind.Relative));
                this.TagRemovedBehavior = TagRemovedBehavior.Disappear; // Having some "update" problems, and doesn't remove the Tag Visualization at once
                
                // There are some un-pinning problems. We haven't found a solution.
            }   
        }

  
    }
}
