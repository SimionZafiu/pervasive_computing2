using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using SurfaceApplication1;
using System.Data;
using System.ComponentModel;
using System.Windows.Threading;

namespace ITU.BasicImageReceiver
{
    
    class BasicImageReceiver
    {

        const int bufferSize = 0x1000;
        const int port = 3000;
       
        private TcpListener tcpListener;
        private Thread listenThread;
        private SurfaceWindow1 surfaceWin;

        public BasicImageReceiver(SurfaceWindow1 surface)
        {
            IPAddress ipAdress = IPAddress.Parse(SurfaceWindow1.SURFACE);
            //this.tcpListener = new TcpListener(IPAddress.Any, port);
            this.tcpListener = new TcpListener(ipAdress, port);
            Console.WriteLine("Server started; available at local IP: " + ipAdress);
            this.surfaceWin = surface;
            
            this.listenThread = new Thread(new ThreadStart(ListenForClients));
            //this.listenThread.SetApartmentState(ApartmentState.MTA);
            this.listenThread.Start();
            //this.listenThread.Join();
        }

        // determines internal (not the global) IP address
        public string localIPAddress()
        {
            IPHostEntry host;
            string localIP = "";
            host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                localIP = ip.ToString();

                String[] temp = localIP.Split('.');
                if ((ip.AddressFamily == AddressFamily.InterNetwork && temp[0] == "192") || (ip.AddressFamily == AddressFamily.InterNetwork && temp[0] == "130") || (ip.AddressFamily == AddressFamily.InterNetwork && temp[0] == "10"))
                {
                    break;
                }
                else localIP = null;
            }
            return localIP;
        }

        // magic stuff
        private void ListenForClients()
        {
            this.tcpListener.Start();
            Console.WriteLine("Waiting for connection ...");

            while (true)
            {
                //blocks until a client has connected to the server
                TcpClient client = this.tcpListener.AcceptTcpClient();
                Console.WriteLine("Connected !");
                //create a thread to handle communication 
                //with connected client
                Thread clientThread = new Thread(new ParameterizedThreadStart(HandleClientComm));
                clientThread.Start(client);
                
            }
        }

        // copies directly from networkstream to file
        // this excellent solution was found on: h ttp://stackoverflow.com/questions/3663369/using-a-networkstream-to-transfer-a-file
        public static long CopyStream(Stream source, Stream target)
        {
            byte[] buf = new byte[bufferSize];

            long totalBytes = 0;
            int bytesRead = 0;

            while ((bytesRead = source.Read(buf, 0, bufferSize)) > 0)
            {
                target.Write(buf, 0, bytesRead);
                totalBytes += bytesRead;
            }

            return totalBytes;
        }

        // checks the destination folder and iterates through files until unique name is found
        string GetUniqueFileName(string ipadr)
        {
            // collect jpeg files in the current directory

            if (!Directory.Exists(ipadr + "\\"))
            {
                DirectoryInfo di = Directory.CreateDirectory(ipadr);
            }

            DirectoryInfo currentDirectory = new DirectoryInfo(Directory.GetCurrentDirectory() + "\\" + ipadr);
            FileInfo[] jpgFiles = currentDirectory.GetFiles("*.jpg");

            // minimum is 0 (plus 1 when returned)
            Int32 highestIteration = 0;

            // find the highest iteration
            foreach (FileInfo jpgFile in jpgFiles)
            {

                // get the file name by itself
                string fileName = jpgFile.Name;
                string nameMinusExtension = fileName.Substring(0, jpgFile.Name.Length - 4);

                Int32 fileIteration;

                // try to convert the filename to integer
                if (Int32.TryParse(nameMinusExtension, out fileIteration))
                {
                    // reassign to the highest integer
                    if (fileIteration > highestIteration)
                    {
                        highestIteration = fileIteration;
                    }
                }
            }

            // return the next number in line
            return (highestIteration + 1) + ".jpg";
        }

        // this does stuff with the incoming connections (copies jpeg files to disk)
        private void HandleClientComm(object client)
        {
            // opens new stream for input from network
            TcpClient tcpClient = (TcpClient) client;
            NetworkStream clientStream = tcpClient.GetStream();

            string ipadr = ((IPEndPoint)tcpClient.Client.RemoteEndPoint).Address.ToString();
            // opens a new stream for output into file
            string fileName = GetUniqueFileName(ipadr);

            FileStream fileStream = new FileStream(ipadr+"\\" + fileName, FileMode.Create, FileAccess.Write);

            // copy everything from the first stream into the second
            long downloadSize = CopyStream(clientStream, fileStream);
            Console.WriteLine(downloadSize + " bytes were downloaded into " + fileName + "!");

            int phoneId = 0;
            if (ipadr == SurfaceWindow1.NEXUS_IP_ADDRESS ) { phoneId = 5; } else { phoneId = 6; }

            string newFileName = Directory.GetCurrentDirectory() + "\\" + ipadr + "\\" + fileName;

            surfaceWin.Dispatcher.Invoke( new Action(() => surfaceWin.UpdateWithImage(newFileName, phoneId)));
            // new Action( })
            // close both again
            tcpClient.Close();
            fileStream.Close();
        }
    }
}
