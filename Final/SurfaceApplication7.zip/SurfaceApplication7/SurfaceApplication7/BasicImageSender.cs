using System;
using System.IO;
using System.Net.Sockets;
using System.Net;

namespace ITU.BasicImageSender
{
	public class BasicImageSender
	{
		public static void SendImage(string ipAddress, int port, string jpgFile) {

			// read in the file
			byte[] fileBuffer = File.ReadAllBytes(jpgFile);
			
			
			// establish a connection to the server
			TcpClient client = new TcpClient();
            IPEndPoint serverEndPoint = new IPEndPoint(IPAddress.Parse(ipAddress), 3000);
		    client.Connect(serverEndPoint);
			NetworkStream clientStream = client.GetStream();

			// send the file
			clientStream.Write(fileBuffer, 0 , fileBuffer.Length);
			clientStream.Flush();
			
			client.Close();
		}


	}
}

