using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Surface;
using Microsoft.Surface.Presentation;
using Microsoft.Surface.Presentation.Controls;
using Microsoft.Surface.Presentation.Input;
using Microsoft.Surface.Presentation.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using ITU.BasicImageReceiver;
using ITU.BasicImageSender;
using System.Threading;
using System.ComponentModel;

namespace SurfaceApplication1
{

        
    /// <summary>
    /// Interaction logic for SurfaceWindow1.xaml
    /// </summary>
    public partial class SurfaceWindow1 : SurfaceWindow
    {
        
        private ObservableCollection<DataItem> sourceItems;
        private readonly BackgroundWorker worker = new BackgroundWorker();
        public const string NEXUS_IP_ADDRESS = "10.6.6.138"; 
        public const string S3_IP_ADDRESS = "10.6.6.172";
        public const string SURFACE = "10.6.6.192"; // In Pitlab: 10.6.6.175
        /// <summary>
        /// Gets the collection that binds with the drag source.
        /// </summary>
        public ObservableCollection<DataItem> SourceItems
        {
            get
            {
                if (sourceItems == null)
                {
                    sourceItems = new ObservableCollection<DataItem>();
                }

                return sourceItems;
            }
        }
        /// <summary>
        /// Default constructor.
        /// </summary>
        public SurfaceWindow1()
        {
         
            DataContext = this;
            InitializeComponent();

            // Add handlers for window availability events
            AddWindowAvailabilityHandlers();

            new BasicImageReceiver(this); // Starting network receiver.
            
        }

        public void UpdateWithImage(string imgFilename, int phoneValue) { 
        
            SourceItems.Add(new DataItem("N/A", true, imgFilename, phoneValue));
            
        }

        /// <summary>
        /// Occurs when the window is about to close. 
        /// </summary>
        /// <param name="e"></param>
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);

            // Remove handlers for window availability events
            RemoveWindowAvailabilityHandlers();
        }

        /// <summary>
        /// Adds handlers for window availability events.
        /// </summary>
        private void AddWindowAvailabilityHandlers()
        {
            // Subscribe to surface window availability events
            ApplicationServices.WindowInteractive += OnWindowInteractive;
            ApplicationServices.WindowNoninteractive += OnWindowNoninteractive;
            ApplicationServices.WindowUnavailable += OnWindowUnavailable;
        }

        /// <summary>
        /// Removes handlers for window availability events.
        /// </summary>
        private void RemoveWindowAvailabilityHandlers()
        {
            // Unsubscribe from surface window availability events
            ApplicationServices.WindowInteractive -= OnWindowInteractive;
            ApplicationServices.WindowNoninteractive -= OnWindowNoninteractive;
            ApplicationServices.WindowUnavailable -= OnWindowUnavailable;
        }

        /// <summary>
        /// This is called when the user can interact with the application's window.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnWindowInteractive(object sender, EventArgs e)
        {
            //TODO: enable audio, animations here

        }

        /// <summary>
        /// This is called when the user can see but not interact with the application's window.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnWindowNoninteractive(object sender, EventArgs e)
        {
            //TODO: Disable audio here if it is enabled

            //TODO: optionally enable animations here
        }

        /// <summary>
        /// This is called when the application's window is not visible or interactive.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnWindowUnavailable(object sender, EventArgs e)
        {
            //TODO: disable audio, animations here
        }

        private void OnVisualizationAdded(object sender, TagVisualizerEventArgs e)
        {
            PhoneVisualization phone = (PhoneVisualization)e.TagVisualization;
            switch (phone.VisualizedTag.Value)
            {
                case 5:
                    
                    phone.phone.Source = new BitmapImage(new Uri(@"Resources\nexus_.png", UriKind.Relative)); // Adds the image of the phone
                    phone.PhoneModel.Content = "Galaxy Nexus"; // Assign a name to the Label of the TagVizualization object
                    break;

                case 6:
                    
                    phone.phone.Source = new BitmapImage(new Uri(@"Resources\s3_.png", UriKind.Relative)); // Adds the image of the phone
                    phone.PhoneModel.Content = "Galaxy S3"; // Assign a name to the Label of the TagVizualization object
                    break;

                default:
                   //phone.PhoneModel.Content = "UNKNOWN PHONE";

                    break;
            }
        }

        private void DragSourcePreviewInputDeviceDown(object sender, InputEventArgs e)
        {
            FrameworkElement findSource = e.OriginalSource as FrameworkElement;
            ScatterViewItem draggedElement = null;

            // Find the ScatterViewItem object that is being touched.
            while (draggedElement == null && findSource != null)
            {
                if ((draggedElement = findSource as ScatterViewItem) == null)
                {
                    findSource = VisualTreeHelper.GetParent(findSource) as FrameworkElement;
                }
            }

            if (draggedElement == null)
            {
                return;
            }

            DataItem data = draggedElement.Content as DataItem;

            // If the data has not been specified as draggable, 
            // or the ScatterViewItem cannot move, return.
            if (data == null || !data.CanDrag || !draggedElement.CanMove)
            {
                return;
            }

            // Set the dragged element. This is needed in case the drag operation is canceled.
            data.DraggedElement = draggedElement;

            // Create the cursor visual.
            ContentControl cursorVisual = new ContentControl()
            {
                Content = draggedElement.DataContext,
                Style = FindResource("CursorStyle") as Style
            };

            // Create a list of input devices, 
            // and add the device passed to this event handler.
            List<InputDevice> devices = new List<InputDevice>();
            devices.Add(e.Device);

            // If there are touch devices captured within the element,
            // add them to the list of input devices.
            foreach (InputDevice device in draggedElement.TouchesCapturedWithin)
            {
                if (device != e.Device)
                {
                    devices.Add(device);
                }
            }

            // Get the drag source object.
            ItemsControl dragSource = ItemsControl.ItemsControlFromItemContainer(draggedElement);

            // Start the drag-and-drop operation.
            SurfaceDragCursor cursor =
                SurfaceDragDrop.BeginDragDrop(
                // The ScatterView object that the cursor is dragged out from.
                  dragSource,
                // The ScatterViewItem object that is dragged from the drag source.
                  draggedElement,
                // The visual element of the cursor.
                  cursorVisual,
                // The data attached with the cursor.
                  draggedElement.DataContext,
                // The input devices that start dragging the cursor.
                  devices,
                // The allowed drag-and-drop effects of the operation.
                  DragDropEffects.Move);

            // If the cursor was created, the drag-and-drop operation was successfully started.
            if (cursor != null)
            {
                // Hide the ScatterViewItem.
                draggedElement.Visibility = Visibility.Hidden;
                draggedElement.CanScale = true;
                draggedElement.IsManipulationEnabled = true;

                // This event has been handled.
                e.Handled = true;
            }
        }

        private void DragCanceled(object sender, SurfaceDragDropEventArgs e)
        {
            DataItem data = e.Cursor.Data as DataItem;
            ScatterViewItem item = data.DraggedElement as ScatterViewItem;
            
            if (item != null)
            {
                item.Visibility = Visibility.Visible;
                item.Orientation = e.Cursor.GetOrientation(this);
                item.Center = e.Cursor.GetPosition(this);
                item.CanScale = true;
                item.IsManipulationEnabled = true;
            }
        }


        private void DragCompleted(object sender, SurfaceDragCompletedEventArgs e)
        {
            // If the operation is Move, remove the data from drag source.
            if (e.Cursor.Effects == DragDropEffects.Move)
            {

                string ipaddress = "";
                int port = 3000;
                    DataItem di = (DataItem)e.Cursor.Data;
                 // MessageBox.Show(di.ImageSource);
                  TagVisualization ta = (TagVisualization) e.Cursor.CurrentTarget;
                 // MessageBox.Show(""+ta.VisualizedTag.Value);
                  if (ta.VisualizedTag.Value == 5) 
                  {
                      ipaddress = NEXUS_IP_ADDRESS;  // Hardcoded IP address of first phone
                      
                  }
                  else if (ta.VisualizedTag.Value == 6) 
                  {
                      ipaddress = S3_IP_ADDRESS;  // Second phone's IP address
                  }
                  
                    // Send Image - do make the path right
                  BasicImageSender.SendImage(ipaddress, port, di.ImageSource);
                  
                  SourceItems.Remove(e.Cursor.Data as DataItem);
            }
        }


    }
    }