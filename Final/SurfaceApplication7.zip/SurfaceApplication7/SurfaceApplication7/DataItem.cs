﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media.Imaging;



namespace SurfaceApplication1
{
    
        public class DataItem 
        {
            private string name;
            private bool canDrag;
            private string imageSource;
            private int phoneValue;

            public string Name
            {
                get { return name; }
            }

            public bool CanDrag
            {
                get { return canDrag; }
            }

            public int PhoneValue
            {

                get { return phoneValue; }
            }

            public string ImageSource
            {
                get { return imageSource; } // Needs to be changed to the right directory (not Images directory)

            }

            public string PhoneBorderColor
            {
                get {
                    if (PhoneValue == 6)
                    {
                        return "Red";  // Second phone (the Galaxy S3)
                    }
                    else if (PhoneValue == 5)
                    {
                        return "Blue"; //  First phone (Nexus)
                    }
                    else {
                        return "Black"; // other
                    }
                }
            }

            public object DraggedElement
            {
                get;
                set;
            }

            public DataItem(string name, bool canDrag, string imageSource, int phoneValue)
            {
                this.name = name;
                this.canDrag = canDrag;
                this.imageSource = imageSource;
                this.phoneValue = phoneValue; 
            }
        
    }
}
